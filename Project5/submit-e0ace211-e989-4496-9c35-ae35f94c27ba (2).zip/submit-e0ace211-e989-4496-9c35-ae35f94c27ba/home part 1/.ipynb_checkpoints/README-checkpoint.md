
I. Summary of the project

Using pyspark to export data from the i94 (https://travel.trade.gov/research/reports/i94/historical/2016.html), airport and codes datasets
Create table (tourisms, airport, time, port_code, state_code, country_code)

- tourisms: records in i94 table
airport_id,type,name,iso_country,iso_region,iata_code,local_code,

- airport:  table of airport codes and corresponding cities
airport_id,type,name,iso_country,iso_region,iata_code,local_code,
- time: timestamps of tourisms for travals
start_time, hour, day, week, month, year, weekday
- port_code: table to explain port from code
name, code
- state_code: table to explain state from code
name, code
- country_code: table to explain country from code
name, code


II. To run project
1. run python file etl.py


III. Explanation of the files in the repository

- Capstone Project Template.ipynb : Construction project step by step

- etl.py: To export data from the i94, airport and codes datasets and insert data to face table (tourisms) and dimension table (airport, time, port_code, state_code, country_code)

- README.md: Construction project

