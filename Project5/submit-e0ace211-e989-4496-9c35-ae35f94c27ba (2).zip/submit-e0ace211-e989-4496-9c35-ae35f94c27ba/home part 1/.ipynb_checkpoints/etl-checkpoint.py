import configparser
from datetime import datetime
import os
import shutil
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
from pyspark.sql.functions import split
from pyspark.sql.functions import udf, col,monotonically_increasing_id
#from pyspark.sql.functions import F year, month, dayofmonth, hour, weekofyear, date_format,
import pyspark.sql.functions as F
from pyspark.sql import types as T
from pyspark.sql.types import StructType as R, StructField as Fld, DoubleType as Dbl, StringType as Str, IntegerType as Int, DateType as Date, TimestampType as Timestamp, FloatType as Float


config = configparser.ConfigParser()
config.read('dl.cfg')

"""
os.environ["AWS_ACCESS_KEY_ID"]= config['AWS']['AWS_ACCESS_KEY_ID']
os.environ["AWS_SECRET_ACCESS_KEY"]= config['AWS']['AWS_SECRET_ACCESS_KEY']
"""


"""
This function to delete parquet files if it existe
"""
def delete_parquet_file(output_data):
    array_table = ["tourisms_table", "time_table","airport_table","port_codes_table", "country_codes_table", "state_codes_table"]
    for li in array_table:
        if os.path.exists(output_data+ li + ".parquet"):
            shutil.rmtree(output_data+ li + ".parquet")
            

"""
This function to create spark session
"""
def create_spark_session():
    spark = SparkSession.builder.\
    config("spark.jars.repositories", "https://repos.spark-packages.org/").\
    config("spark.jars.packages", "saurfang:spark-sas7bdat:2.0.0-s_2.11").\
    enableHiveSupport().getOrCreate()
    return spark


"""
This function to copy i94 data from sas7bdat and create tourisms_table,time_table

input:
+ spark : from create_spark_session function
+ input_data : path of input data
+ output_data : path of output data
"""
def process_i94_data(spark, input_data, output_data):
    
    # get filepath to i94 data file
    format_sas = "com.github.saurfang.sas.spark"
    i94_data = "../../data/18-83510-I94-Data-2016/i94_apr16_sub.sas7bdat"

    # read song data file
    df_i94 = spark.read.format(format_sas).load(i94_data)

    # extract columns to create songs table
    # Performing cleaning tasks here
    #change type of column of i94
    df_i94 = df_i94 \
      .withColumn("cicid" ,
                  df_i94["cicid"]
                  .cast(T.IntegerType()))   \
      .withColumn("i94yr",
                  df_i94["i94yr"]
                  .cast(T.IntegerType()))    \
      .withColumn("i94mon"  ,
                  df_i94["i94mon"]
                  .cast(T.IntegerType())) \
      .withColumn("i94cit" ,
                  df_i94["i94cit"]
                  .cast(T.IntegerType()))   \
      .withColumn("i94res",
                  df_i94["i94res"]
                  .cast(T.IntegerType()))    \
      .withColumn("arrdate"  ,
                  df_i94["arrdate"]
                  .cast(T.TimestampType())) \
      .withColumn("depdate"  ,
                  df_i94["depdate"]
                  .cast(T.TimestampType())) \
      .withColumn("dtadfile"  ,
                  df_i94["dtadfile"]
                  .cast(T.TimestampType())) \
      .withColumn("biryear"  ,
                  df_i94["biryear"]
                  .cast(T.IntegerType())) \
      .withColumn("dtaddto"  ,
                  df_i94["dtaddto"]
                  .cast(T.TimestampType())) 


    # extract columns to create tourisms table
    tourisms_table = df_i94.select(F.col("fltno").alias("flights_id"),
                                F.col("airline").alias("airlines_id"),
                                F.col("arrdate").alias("arrival_date"),
                                F.col("depdate").alias("departure_date"),
                                F.col("entdepa").alias("arrival_flag"),
                                F.col("entdepd").alias("departure_flag"),
                                F.col("entdepu").alias("update_flag"),
                                F.col("matflag").alias("match_flag"),
                                F.col("gender").alias("gender"),
                                F.col("i94mode").alias("model"),
                                F.col("i94addr").alias("state"),
                                F.col("i94port").alias("port"),
                                F.col("i94cit").alias("country")
                                )
    
    # remove the duplicate records
    tourisms_table = tourisms_table.drop_duplicates()
    
    # write tourisms table to parquet files 
    tourisms_table.write.parquet(output_data+"tourisms_table.parquet")
    
    # create datetime column from original timestamp column
    # get_datetime = udf()
    
    df_time = df_i94
    df_time = df_i94.withColumn("hour", F.hour("depdate"))
    df_time = df_time.withColumn("day", F.dayofmonth("depdate"))
    df_time = df_time.withColumn("week", F.weekofyear("depdate"))
    df_time = df_time.withColumn("month", F.month("depdate"))
    df_time = df_time.withColumn("year", F.year("depdate"))
    df_time = df_time.withColumn("weekday", F.dayofweek("depdate"))

    # extract columns to create time table
    time_table = df_time.select(F.col("depdate").alias("start_time"),
                          F.col("hour"),
                          F.col("day"),
                          F.col("week"),
                          F.col("month"),
                          F.col("year"),
                          F.col("weekday")
                         )
    
    # remove the duplicate records
    time_table = time_table.drop_duplicates()
    
    # write time table to parquet files partitioned by year and month
    time_table.write.parquet(output_data+"time_table.parquet")

"""
This function to copy airport data from csv and create airport_table

input:
+ spark : from create_spark_session function
+ input_data : path of input data
+ output_data : path of output data
"""
def process_airport_data(spark, input_data, output_data):
    # get filepath to log data file
    airport_data = input_data + "airport-codes_csv.csv"

    # read airport data file
    df_airports = spark.read.option("header",True).csv(airport_data)
    
    df_airports = df_airports.withColumn("airport_id",
                      F.col("ident").substr(-2,2))

    # extract columns for users table    
    airport_table = df_airports.select(F.col("airport_id"),
                            F.col("type"),
                            F.col("name"),
                            F.col("iso_country"),
                            F.col("iso_region"),
                            F.col("iata_code"),
                            F.col("local_code")
                           )

    # remove the duplicate records
    airport_table = airport_table.drop_duplicates()
    
    # write users table to parquet files
    airport_table.write.parquet(output_data+"airport_table.parquet")

    
"""
This function to copy port-codes data from csv and create port_codes_table

input:
+ spark : from create_spark_session function
+ input_data : path of input data
+ output_data : path of output data
"""
def process_port_data(spark, input_data, output_data):
    # get filepath to port data file
    port_data = input_data + "port-codes_csv.csv"

    # read port data file
    df_port = spark.read.option("header",True).csv(port_data)

    # extract columns for port table    
    port_table = df_port.select(F.col("code"),
                            F.col("name"))

    # remove the duplicate records
    port_table = port_table.drop_duplicates()
    
    # write port table to parquet files
    port_table.write.parquet(output_data+"port_codes_table.parquet")
    
    
"""
This function to copy state-codes data from csv and create state_codes_table

input:
+ spark : from create_spark_session function
+ input_data : path of input data
+ output_data : path of output data
"""
def process_state_data(spark, input_data, output_data):
    # get filepath to state code data file
    state_data = input_data + "state-codes_csv.csv"

    # read state code data file
    df_state = spark.read.option("header",True).csv(state_data)

    # extract columns for state table    
    state_table = df_state.select(F.col("code"),
                            F.col("name"))

    # remove the duplicate records
    state_table = state_table.drop_duplicates()
    
    # write state table to parquet files
    state_table.write.parquet(output_data+"state_codes_table.parquet")
                                
"""
This function to copy country-codes data from csv and create country_codes_table

input:
+ spark : from create_spark_session function
+ input_data : path of input data
+ output_data : path of output data
"""
def process_country_data(spark, input_data, output_data):
    # get filepath to country code data file
    country_data = input_data + "country-codes_csv.csv"

    # read country code data file
    df_country = spark.read.option("header",True).csv(country_data)

    # extract columns for country table    
    country_table = df_country.select(F.col("code"),
                            F.col("name"))

    # remove the duplicate records
    country_table = country_table.drop_duplicates()
    
    # write country table to parquet files
    country_table.write.parquet(output_data+"country_codes_table.parquet")
    
    
"""
This function to check data for one table

input:
+ spark : from create_spark_session function
+ table : name of table for check data
+ output_data : path of output data
""" 
def check_data_table(spark, output_data, table ):
    if os.path.exists(output_data+ table + ".parquet"):
        check=spark.read.parquet(output_data+ table + ".parquet")
        if (check.count() > 0):
            return check.count()
        else:
            return "No"
    else:
        return "No"    

    
"""
This function to check data for all table

input:
+ spark : from create_spark_session function
+ output_data : path of output data
""" 
def check_data(spark, output_data):
    rows = []
    array_table = ["tourisms_table", "time_table","airport_table","port_codes_table", "country_codes_table", "state_codes_table"]
    for li in array_table:
        check = check_data_table(spark, output_data, li)
        rows.append([li, check])
    columns = ['table', 'check']
    df_check_data = spark.createDataFrame(rows, columns)
    return df_check_data
        
    
"""
This function to execute create_spark_session fucntion, delete_parquet_file function, process_i94_data function,
process_airport_data fucntion, process_port_data function, process_state_data function, process_country_data function
"""
def main():
    spark = create_spark_session()
    input_data = "input_data/"
    output_data = "output_data/"
    
    delete_parquet_file(output_data)
    
    process_i94_data(spark, input_data, output_data)    
    process_airport_data(spark, input_data, output_data)
    process_port_data(spark, input_data, output_data)
    process_state_data(spark, input_data, output_data)
    process_country_data(spark, input_data, output_data)

    #check data
    check_data(spark, output_data)

if __name__ == "__main__":
    main()
