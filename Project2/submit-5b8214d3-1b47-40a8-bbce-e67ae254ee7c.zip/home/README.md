
I. Summary of the project

A music streaming startup, Sparkify, has grown their user base and song database and want to move their processes and data onto the cloud. Their data resides in S3, in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

Using sql to export data from the song and log datasets
Create  create a star schema with face table (songplays) and dimension table (users, songs, artists, time)

- songplays: records in log data associated with song plays
songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

- users: users in the app
user_id, first_name, last_name, gender, level
- songs: songs in music database
song_id, title, artist_id, year, duration
- artists: artists in music database
artist_id, name, location, latitude, longitude
- time: timestamps of records in songplays broken down into specific units
start_time, hour, day, week, month, year, weekday


II. To run project
1. run python file create_table.py
2. run test.ipynb to check
3. run etl.py file
4. Then run test.ipynb to check


III. Explanation of the files in the repository

- create_tables.py: To create table

- dwh.cfg: Parametre of S3

- etl.py: To export data from the song and log datasets and insert data to face table (songplays) and dimension table (users, songs, artists, time)

- README.md: Construction project

- sql_queries.py: Queries to create, insert and drop table, using in etl.ipynb and etl.py
