
I. Summary of the project

Using pyspark to export data from the song and log datasets
Create table (songplays, users, songs, artists, time)

- songplays: records in log data associated with song table
songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent

- users: users in the app
user_id, first_name, last_name, gender, level
- songs: songs in music database
song_id, title, artist_id, year, duration
- artists: artists in music database
artist_id, name, location, latitude, longitude
- time: timestamps of records in songplays broken down into specific units
start_time, hour, day, week, month, year, weekday


II. To run project
1. run python file etl.py


III. Explanation of the files in the repository

- dl.cfg: Parametre of aws

- etl.py: To export data from the song and log datasets and insert data to face table (songplays) and dimension table (users, songs, artists, time)

- README.md: Construction project

