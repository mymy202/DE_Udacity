from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 # Define your operators params (with defaults)
                 redshift_conn_id="",
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        # Map params
        self.redshift_conn_id = redshift_conn_id

    def execute(self, context):
        self.log.info('DataQualityOperator not implemented yet')
        redshift_hook = PostgresHook(self.redshift_conn_id)
        
        records = redshift_hook.get_records(f"SELECT COUNT(*) FROM user")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. user returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. user contained 0 rows")
        logging.info(f"Data quality on table user check passed with {records[0][0]} records")
        
        records = redshift_hook.get_records(f"SELECT COUNT(*) FROM song")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. song returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. song contained 0 rows")
        logging.info(f"Data quality on table song check passed with {records[0][0]} records")
  
        records = redshift_hook.get_records(f"SELECT COUNT(*) FROM artist")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. artist returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. artist contained 0 rows")
        logging.info(f"Data quality on table artist check passed with {records[0][0]} records")

        records = redshift_hook.get_records(f"SELECT COUNT(*) FROM time")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. time returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. time contained 0 rows")
        logging.info(f"Data quality on table time check passed with {records[0][0]} records")
        
        records = redshift_hook.get_records(f"SELECT COUNT(*) FROM songplays")
        if len(records) < 1 or len(records[0]) < 1:
            raise ValueError(f"Data quality check failed. songplays returned no results")
        num_records = records[0][0]
        if num_records < 1:
            raise ValueError(f"Data quality check failed. songplays contained 0 rows")
        logging.info(f"Data quality on table songplays check passed with {records[0][0]} records")
        
        
        self.log.info('DataQualityOperator implemented')            
         